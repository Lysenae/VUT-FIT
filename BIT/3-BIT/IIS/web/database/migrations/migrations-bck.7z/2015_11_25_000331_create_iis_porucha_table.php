<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateIisPoruchaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('iis_porucha', function(Blueprint $table)
		{
			$table->increments('poruchaID', 5);
			$table->string('k_oprave', 5)->index('poskozeno');
			$table->integer('technik', 10)->index('opravil');
			$table->string('oznamujici', 5)->index('oznamil');
			$table->string('popis')->nullable();
			$table->date('cas_oznam')->nullable();
			$table->string('zprava_opravy')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('iis_porucha');
	}

}
