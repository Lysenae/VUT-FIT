<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateIisPresunTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('iis_presun', function(Blueprint $table)
		{
			$table->string('presunID', 5)->primary();
			$table->string('zarizeni', 5)->index('presunuto');
			$table->string('zaDATEl', 5)->index('zadal');
			$table->string('duvod')->nullable();
			$table->date('provedeno')->nullable();
			$table->date('cas_zadosti')->nullable();
			$table->string('odkud', 7);
			$table->string('kam', 7);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('iis_presun');
	}

}
