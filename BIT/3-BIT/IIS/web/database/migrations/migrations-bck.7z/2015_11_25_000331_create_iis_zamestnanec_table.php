<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateIisZamestnanecTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('iis_zamestnanec', function(Blueprint $table)
		{
			$table->increments('zamID', 5);
			$table->integer('rodnecislo');
			$table->string('pracoviste', 7)->index('sidlil');
			$table->integer('prava')->index('mel');
			$table->string('login', 10)->nullable()->unique('login');
			$table->string('jmeno', 20);
			$table->string('prijmeni', 20);
			$table->string('heslo', 60)->nullable();
			$table->date('datum_narozeni')->nullable();
			$table->integer('mobil')->nullable();
			$table->integer('telefon_kancelar')->nullable();
			$table->string('mail')->nullable();
			$table->boolean('aktivni')->default(1);
			$table->string('remember_token', 100)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('iis_zamestnanec');
	}

}
